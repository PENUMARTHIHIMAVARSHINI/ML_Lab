#Q1. Vector, V1, length = 100. Sorting: Ascending order
import numpy as np
V1 = np.random.random(100) #generating a random number vector of length 100
print(V1)
V1_sort = np.sort(V1) # sorting the vector 
print(V1_sort)

#Q2. Multiply V1*3
V1_mul = V1_sort*3
print(V1_mul)

#Q3. Mean, Standard deviation
mean = np.mean(V1)
print(mean)
std = np.std(V1)
print(std)

#Q4. Zero matrix (4r,3c), fill with numbers, convert to 1D
M1 = np.zeros((4,3))
print(M1)
M2 = np.random.random((4,3))
print(M2)
M3 = M2.flatten()
print(M3)

#Q5. Search substring from given string S1  {considering Am is am} 
S1 = "I am a great learner. I am going to have an awesome life."
substring = "am"
if substring in S1:
    occ_count = S1.count(substring)
    print("am is a substring of the string in S1 and occurs", occ_count, "times")
else:
    print("am is not a substring of the string in S1")

#Q6. Combine strings
S2 = "I work hard and shall be rewarded well."
S3 = S1 + S2
print(S3)

#Q7. Split strings, make an array and find the length of the array
S3_split = S3.replace('.', ' ').split()
print(S3_split)
len(S3_split)

#Q8. Remove words from S3. Find the length of the array.
remove = {"I", "am", "to", "and"}
for i in list(S3_split):
    if i in remove or len(i)>6:
        S3_split.remove(i)
print(S3_split)

#Q9. Date: 01-JUN-2021
date = "01-JUN-2021"
date,month_name,year = date.split("-")
print(date)
print(month_name)
print(year)
months = {"JAN":1, "FEB":2, "MAR":3, "APR":4, "MAY":5, "JUN":6, "JUL":7, "AUG":8, "SEP":9, "OCT":10, "NOV":11, "DEC":12}
month = months[month_name]
print(month_name,"=",month)

#Q10. Excel manipulation
import pandas as pd
table = {"City": ["BENGALURU", "CHENNAI", "MUMBAI", "MYSURU", "PATNA", "JAMMU", "GANDHI NAGAR", "HYDERABAD", "ERNAKULAM", "AMARAVATI"], "State": ["KA","TN","MH","KA","BH","JK","GJ","TS","KL","AP",], "PIN Code":[560001,600001,400001,570001,800001,180001,382001,500001,682001,522001]}
df = pd.DataFrame(table)
df['City,State'] = df['City']+ "," +df['State']
write = "LabSession00.xlsx"
df.to_excel(write,index = False)

#Q11. Plot sorted vector V1 and change color
import matplotlib.pyplot as plt
plt.plot(V1_sort)
plt.show()

plt.plot(V1_sort,color = 'red')
plt.show()

#Q12. Vector V2 must have the squared values of V1 vector
V2 = V1**2
plt.plot(V1, label = "V1", color = 'red', linestyle = ':')
plt.plot(V2, label = "V2", color = 'yellow', linestyle = '--')
plt.title("Plot of V1 and V2")
plt.legend()
plt.show()
