"Lab Session - 01 by Penumarthi Hima Varshini [BL.EN.U4AIE23046]"


#Question 1
def get():
    return input("Enter a string ")

def count(string):
    vowels = ['A','E','I','O','U','a','i','e','o','u']
    vowels_count= 0
    consonants_count = 0
    for i in string:
        if i.isalpha(): #Alphabets only
            if (i in vowels):
                vowels_count += 1
            else:
                consonants_count += 1
    return vowels_count, consonants_count

string = get()
vowels_count, consonants_count = count(string)
print("Count of vowels", vowels_count)
print("Count of consonants", consonants_count)


#Question 2
def order_of_matrix(matrix):
    try:
        r = int(input(f"Enter the number of rows for {matrix}: "))
        c = int(input(f"Enter the number of columns for {matrix}: "))
        if r <= 0 or c <= 0:
            raise ValueError("Dimensions must be greater than 0. Please check")
        return r,c
    except ValueError as x:
        print("Wrong order of the matrix." , x)
        raise

def mat(r,c,matrix):
    try:
        m = []
        for  i in range(r):
            for j in range(c):
                while True:
                    try:
                        a = int(input(f"Enter the element of {i}{j} for {matrix}"))
                        print("Element in ", i,j, "is", a)
                        if len(m) <= i:
                            m.append([])
                        m[i].append(a)
                        break
                    except ValueError:
                        print("Enter numbers only")       
        return m
    except ValueError as y:
        print("Check your input." , y)
        raise
    
def mul(matrixA, matrixB):
    try:
        rA, cA = len(matrixA), len(matrixA[0])
        rB, cB = len(matrixB), len(matrixB[0])
        if cA != rB:
            raise ValueError("Columns of Matrix A and Rows of Matrix B must be equal in order to multiply two matrices")
        product = [[0 for _ in range(cB)]for _ in range(rA)]
        for i in range(rA):
            for j in range(cB):
                for k in range(cA):
                    product[i][j] += matrixA[i][k] * matrixB[k][j]
        return product
    except ValueError as z:
        print("Error in multiplication",z)
        raise

r1, c1 = order_of_matrix("Matrix A")
r2, c2 = order_of_matrix("Matrix B")

matrixA = mat(r1,c1,"Matrix A")
matrixB = mat(r2,c2, "Matrix B")

print("Matrix A: ")
for i in matrixA:
    print(i)

print("Matrix B: ")
for j in matrixB:
    print(j)
    
r = mul(matrixA, matrixB)

print("Multiplication of matrices: ")
for k in r:
    print(k)

    
#Question 3
def get_list():
    while True:
        try:
            length = int(input("Enter the number of elements in the list: "))
            if length <= 0:
                raise ValueError("List must have atleast 1 element")
            l1 = []
            for i in range(length):
                while True:
                    try:
                        a = int(input(f"Enter element {i+1}: "))
                        l1.append(a)
                        break
                    except ValueError:
                        print("Please input only integers")
            return l1
        except ValueError as y:
            print(y)
            
def common(list1, list2):
    com = set(list1) & set(list2)
    return com

def count_com(com):
    return len(com)

print("Elements for list 1: ")
list1 = get_list()

print("Elements for list 2: ")
list2 = get_list()

print("Common elements in list1 and list2 are ", common(list1,list2))
print("Total number of common elements in list1 and list2 are ", count_com(common(list1,list2)))


#Question 4
def order_of_matrix(matrix):
    try:
        r = int(input(f"Enter the number of rows for {matrix}: "))
        c = int(input(f"Enter the number of columns for {matrix}: "))
        if r <= 0 or c <= 0:
            raise ValueError("Dimensions must be greater than 0. Please check")
        return r,c
    except ValueError as x:
        print("Wrong order of the matrix." , x)
        raise

def mat(r,c,matrix):
    try:
        m = []
        for  i in range(r):
            for j in range(c):
                while True:
                    try:
                        a = int(input(f"Enter the element of {i}{j} for {matrix}"))
                        print("Element in ", i,j, "is", a)
                        if len(m) <= i:
                            m.append([])
                        m[i].append(a)
                        break
                    except ValueError:
                        print("Enter numbers only")       
        return m
    except ValueError as y:
        print("Check your input." , y)
        raise

def transpose(m):
    return [list(i) for i in zip(*m)]
#zip will take the corresponding elements from the matrix to tuples which are in the form of lists and we use list to make them as lists

r, c = order_of_matrix("Matrix A")

matrixA = mat(r,c,"Matrix A")

print("Matrix A: ")
for i in matrixA:
    print(i)
    
t = transpose(matrixA)

print("Transpose of Matrix A is : ")
for k in t:
    print(k)


#Question 5
def get():
    try:
        a = int(input("Enter a number"))
        if a <= 1:
            raise ValueError("Enter positive numbers only: ")
        return a
    except ValueError as e:
        print(e)
        return None

def check_prime(a):
    if a <= 1:
        return False
    for i in range(2,a):
        if a % i == 0:
            return False
    return True

n = get()
if n is not None:
    r = check_prime(n)
    if r:
        print(n, "is a prime number")
    else:
        print(n, "is not a prime number")

